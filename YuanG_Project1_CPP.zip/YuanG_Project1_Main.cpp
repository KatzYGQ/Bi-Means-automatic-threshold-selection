﻿#include <iostream>
#include <fstream>
#include <cmath>
#include <cstring>

using namespace std;

class thresholdSelection {

public:

    int numRows, numCols, minVal, maxVal; //image header
    int BiGaussThrVal; // the auto selected threshold value by the Bi-Gaussian method
    int histHeight; //The largest hist[i] in the input histogram.
    int maxHeight; //The largest hist[i] within a given range of the histogram.
    int* histAry;//a 1D integer array (size of maxVal + 1) to store the histogram.
    int* GaussAry;// a 1D integer array (size of maxVal + 1) to store the “modified” Gaussian curve values.
    int* bestFitGaussAry; // to store the best biGaussian curves.
    char** Graph; /// a 2-D char array size of maxVal+1 by histHeight+1, initialize to blank,



    thresholdSelection(int nRows, int nCols, int minV, int maxV)
        : numRows(nRows), numCols(nCols), minVal(minV), maxVal(maxV), BiGaussThrVal(0),
        histHeight(0), maxHeight(0) {

        histAry = new int[maxVal + 1]();
        GaussAry = new int[maxVal + 1]();
        bestFitGaussAry = new int[maxVal + 1]();

        Graph = new char* [maxVal + 1];
        for (int i = 0; i <= maxVal; i++) {
            Graph[i] = new char[numCols + 1](); // Assuming numCols is appropriate
            for (int j = 0; j <= numCols; j++) {
                Graph[i][j] = ' '; // Initialize to blank
            }
        }
    }

    int loadHist(ifstream &inFile) {
        int histValue, count;
        int maxhistHeight = 0;
        while (inFile >> histValue >> count) {
            histAry[histValue] = count;
            if (count > maxhistHeight) maxhistHeight = count;
        }
        histHeight = maxhistHeight;
        // Initialize Graph with new histHeight
        for (int i = 0; i <= maxVal; i++) {
            delete[] Graph[i];
            Graph[i] = new char[histHeight + 1]();
            std::fill_n(Graph[i], histHeight + 1, ' ');
        }

        inFile.close();
        return histHeight;
    }

    //Output the histogram in the format as shown in the above
    //1 (2):++ 
    //2 (3):+++
    //3 (5):++++++

    void dispHist(ofstream& outFile) {

        for (int i = 0; i <= maxVal; i++) {
            outFile << i << " (" << histAry[i] << "):";
            for (int j = 0; j < histAry[i]; j++) {
                outFile << "+";
            }
            outFile << endl;
        }
    }

    // copy ary1 to ary2.
    void copyArys(int* ary1, int* ary2) {
        for (int i = 0; i <= maxVal; i++) {
            ary2[i] = ary1[i];
        }
    }

    /// plot the histogram onto Graph with ‘+’.
    void plotHist() {

        for (int i = 0; i <= maxVal; i++) {
            for (int j = 0; j < histAry[i]; j++) {
                Graph[i][j] = '+';
            }
        }
    }

    // Set 1D Ary to zero;
    void setZero(int* Ary) {
        for (int i = 0; i <= maxVal; i++)
            Ary[i] = 0;
    }

    int biGaussian(ofstream& deBugFile) {
        deBugFile << "Entering biGaussian method\n" << endl;
        double sum1, sum2, total, minSumDiff = 99999.0;
        int offSet = (maxVal - minVal) / 10;
        int dividePt = offSet, bestThr = dividePt;

        while (dividePt < (maxVal - offSet)) { //step8 repeat
            //step1
            setZero(GaussAry); // Reset GaussAry to zero for each iteration
            //step 2-4
            sum1 = fitGauss(0, dividePt, deBugFile); // Fit first Gaussian curve
            sum2 = fitGauss(dividePt + 1, maxVal, deBugFile); // Fit second Gaussian curve
            total = sum1 + sum2;
            //step5
            if (total < minSumDiff) {
                minSumDiff = total;
                bestThr = dividePt;
                for (int i = 0; i <= maxVal; i++) {
                    bestFitGaussAry[i] = GaussAry[i]; // Copy GaussAry to bestFitGaussAry
                }
            }
            //step6
            deBugFile << "In biGaussian(): dividePt = " << dividePt
                << ", sum1= " << sum1 << ", sum2= " << sum2
                << ", total= " << total << ", minSumDiff = " << minSumDiff
                << " and bestThr=" << bestThr << "\n";
            //step7
            dividePt++;
        }

        //step 9
        deBugFile << "Leaving biGaussian method, minSumDiff = " << minSumDiff
            << ", bestThr is " << bestThr << "\n";
        //step10
        return bestThr;
    }


    double fitGauss(int leftIndex, int rightIndex, ofstream& deBugFile) {
        //step0
        deBugFile << "Entering fitGauss method\n";
        //step1
        double mean = computeMean(leftIndex, rightIndex, deBugFile);
        double var = computeVar(leftIndex, rightIndex, mean, deBugFile);
        double sum = 0.0;
        //step2,6,7
        for (int index = leftIndex; index <= rightIndex; index++) {
            //step3
            double Gval = modifiedGauss(index, mean, var);
            //step4
            sum += abs(Gval - (double)(histAry[index]));
            //step5
            GaussAry[index] = (int)(Gval);
        }
        //step8
        deBugFile << "Leaving fitGauss method, sum is " << sum << "\n";
        //step9
        return sum;
    }


    double computeMean(int leftIndex, int rightIndex, ofstream& deBugFile) {
        //step0
        deBugFile << "Entering computeMean method" << endl;
        double sum = 0.0;
        int numPixels = 0;

        //step1,4,5
        for (int index = leftIndex; index <= rightIndex; index++) {
            //step2
            sum += (double)(index)*histAry[index];
            numPixels += histAry[index];
            //step3
            if (histAry[index] > maxHeight) {
                maxHeight = histAry[index]; // Update maxHeight if current hist value is greater
            }
        }
        //step6
        double result = (numPixels > 0) ? sum / (double)numPixels : 0;
        //step7
        deBugFile << "Leaving computeMean method. maxHeight is " << maxHeight << " and result is " << result << endl;
        //step8
        return result;
    }


    double computeVar(int leftIndex, int rightIndex, double mean, ofstream& deBugFile) {
        //step 0
        deBugFile << "Entering computeVar() method" << endl;
        double sum = 0.0;
        int numPixels = 0;

        //step1,3,4
        for (int index = leftIndex; index <= rightIndex; index++) {
            double diff = index - mean;
            //step2
            sum += (double)histAry[index] * diff * diff; // Weighted sum of squared differences
            numPixels += histAry[index];
        }


        //step 5
        double result = (numPixels > 0) ? sum / (double)numPixels : 0; \
            //step6
            deBugFile << "Leaving computeVar method returning result " << result << endl;
        //step7
        return result;
    }



    double modifiedGauss(int x, double mean, double var) {
        return (double)maxHeight * exp(-pow(x - mean, 2) / (2 * var));
    }



    void printGraph(ofstream& deBugFile) {
        for (int j = histHeight; j >= 0; --j) {
            for (int i = 0; i <= maxVal; ++i) {
                deBugFile << Graph[i][j];
            }
            deBugFile << endl;
        }

    }

  


    void plotGaussCurves(ofstream& deBugFile) {
        //step 0
        deBugFile << "Entering plotGaussCurves() method\n";

        //step1: index <-0
        for (int index = 0; index <= maxVal; index++) {
            int end1, end2;

            //step2
            if (bestFitGaussAry[index] <= histAry[index]) {
                end1 = bestFitGaussAry[index];
                end2 = histAry[index];
            }
            else {
                end1 = histAry[index];
                end2 = bestFitGaussAry[index];
            }

            for (int i = end1; i <= end2; i++) {
                if (i >= 0 && i <= histHeight) {
                    Graph[index][i] = '#'; // Mark the gap
                }
            }


            if (bestFitGaussAry[index] >= 0 && bestFitGaussAry[index] <= histHeight) {
                Graph[index][bestFitGaussAry[index]] = '*'; // Mark the Gaussian curve point
            }
            deBugFile << "Leaving plotGaussCurves()" << endl;
        }


    }
};

int main(int argc, char* argv[]) {
    //step0
    ifstream inFile1(argv[1]);
    ofstream outFile1(argv[2]);
    ofstream outFile2(argv[3]);
    ofstream deBugFile(argv[4]);
    
    //step1
    int numRows, numCols, minVal, maxVal;
    inFile1 >> numRows >> numCols >> minVal >> maxVal;

    thresholdSelection ts(numRows, numCols, minVal, maxVal); // Create an instance of thresholdSelection
   
    ts.loadHist(inFile1);

    //Step 2
    outFile1 << "In main(), below is the input histogram" << endl;
    ts.dispHist(outFile1);

    //step3.
    ts.plotHist();
    deBugFile << "In main(), below is the Graph after plotting the histogram onto Graph:" << std::endl;

    ts.printGraph(deBugFile);

    // Step 4: Determine BiGaussian Threshold Value
    int biGaussThrVal = ts.biGaussian(deBugFile);

    // Step 5: Output the BiGaussian Threshold Value
    outFile2 << "The BiGaussThrVal is " << biGaussThrVal << std::endl;

    // Step 6: Plot Gaussian Curves on the Graph
    ts.plotGaussCurves(deBugFile); // Adjust parameters as needed based on class implementation

    // Step 7: Output the final graph
    outFile2 << "In main(). Below is the graph showing the histogram, the best fitted Gaussian curves and the gap" << endl;
    ts.printGraph(outFile2); // Reuse printGraph method to output the final Graph to outFile2

    inFile1.close();
    outFile1.close();
    outFile2.close();
    deBugFile.close();
}

